﻿using CookieClickerEF.Models;
using Microsoft.EntityFrameworkCore;

namespace CookieClickerEF.Context
{
    public class CookieClickerContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=CookieClicker.db;");
        }

        public DbSet<GameState> GameStates { get; set; }
    }
}
