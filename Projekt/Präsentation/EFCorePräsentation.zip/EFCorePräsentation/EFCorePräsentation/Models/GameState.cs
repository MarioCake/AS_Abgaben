﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CookieClickerEF.Models
{
    public class GameState
    {
        public int Id { get; set; }
        public int Money { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
