﻿using System;
using CookieClickerEF.Context;
using CookieClickerEF.Models;

namespace CookieClickerEF
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CookieClickerContext context = new CookieClickerContext();

            GameState newGameState = new GameState()
            {
                Money = 15000,
                CreatedAt = DateTime.Now
            };

            context.GameStates.Add(newGameState);
            try
            {
                context.SaveChanges();
            }catch
            {
                Console.WriteLine("Kann die Datenbankverbindung nicht aufbauen.");
                return;
            }

            foreach(GameState state in context.GameStates)
            {
                if (state.Money < 5000)
                {
                    state.Money = (int)(state.Money * 1.1);
                }
            }

            try
            {
                context.SaveChanges();
            }
            catch
            {
                Console.WriteLine("Kann die Datenbankverbindung nicht aufbauen.");
                return;
            }
        }
    }
}
